from django.shortcuts import render
from Weatherapp.assts import call

# Create your views here.
def home(request):
    
    data= call.temp(request.POST.get('cityname'))
    current = call.currentD(data)
    today = call.todays(data)
    daily = call.dailyd(data)


    return render(request,"base.html",{'current':current,"today":today,'daily':daily})
