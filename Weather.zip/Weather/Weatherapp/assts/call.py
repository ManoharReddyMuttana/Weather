import requests as req
import datetime
import math

def temp(city="hyderabad"):
    city_name=city
    if city == None:
        city_name='hyderabad'

    api="4b36e36edb1ebaa56b97dba18fa29721"
    url=f"https://api.openweathermap.org/data/2.5/weather?q={city_name}&appid={api}"
    reqs=req.get(url).json()
    if reqs['cod'] == 404:
        city_name='hyderabad'
        reqs=req.get(url).json()
    lon =reqs["coord"]["lon"]
    lat =reqs["coord"]["lat"]
    url1=f"https://api.openweathermap.org/data/3.0/onecall?lat={lat}&lon={lon}&appid={api}"
    data = req.get(url1).json()

    data['city'] =city_name.title

    return  data

print(temp('hyderabad'))

def currentD(data):
    current ={}
    current['city'] = data['city']
    current['day'] = day( data['current']['dt'])
    current['condition'] = data['current']['weather'][0]['main']
    current['tempc'] = round(data['current']['temp']-273.15)
    current['tempf'] = round(current['tempc'] * (9/5) +32)
    current['tempimg'] = data['current']['weather'][0]['icon']
    current['feels'] = round(data['current']['feels_like']-273.15)
    return current

def day(date):  
    current_datetime =datetime.datetime.fromtimestamp( date)
    day_of_week = current_datetime.weekday()
    days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
    day_name = days[day_of_week]
    return day_name


def todays(data):
    today={}
    today['day'] = day(data['daily'][0]['dt'])
    today['temp'] =round( data['daily'][0]['temp']['day']-273.15)
    today['min'] =round( data['daily'][0]['temp']['min'] -273.15 )
    today['max'] =round( data['daily'][0]['temp']['max'] -273.15 )
    today['feels'] = round(data['daily'][0]['feels_like']['day'] - 273.15)
    today['humidity'] = data['daily'][0]['humidity']
    today['pressure']  =data['daily'][0]['pressure']
    today['cloud'] =data['daily'][0]['weather'][0]['main']
    return today

def dailyd(data):
    data1=[]
    for i in range(len(data['daily'])-1):
        val={}
        val['dt']=dates(data['daily'][i]['dt'])
        val['icon'] =data['daily'][i]['weather'][0]['icon']
        val['temp']=round(data['daily'][i]['temp']['day']-273.15)
        val['condition']=data['daily'][i]['weather'][0]['main']
        data1.append(val)
    return data1 

def dates(x):
    date_time = datetime.datetime.fromtimestamp(x)
    formatted_date = date_time.strftime('%A %b %d')
    return formatted_date